/**
 * 
 * @author revised by Eugene Domrachev
 * 
 * The recipient of the Office Depot donation.
 *
 */
public class Recipient {
	
	public String name;
	
	public Recipient(String s) {
		name = s;
	}

	public String toString() {
		return name;
	}

}
