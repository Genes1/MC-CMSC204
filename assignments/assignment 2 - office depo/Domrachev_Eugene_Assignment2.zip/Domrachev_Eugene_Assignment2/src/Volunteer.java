/**
 * 
 * @author revised by Eugene Domrachev
 * 
 * The volunteer which delivers the Office Depot donation.
 *
 */
public class Volunteer {
	
	public String name;
	
	public Volunteer(String s) {
		name = s;
	}

	public String toString() {
		return name;
	}

}
